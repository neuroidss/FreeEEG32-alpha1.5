This folder contains signals recorded by the SSVEP scenarios.
