This folder contains classifiers and CSP filters created by the SSVEP scenarios.
