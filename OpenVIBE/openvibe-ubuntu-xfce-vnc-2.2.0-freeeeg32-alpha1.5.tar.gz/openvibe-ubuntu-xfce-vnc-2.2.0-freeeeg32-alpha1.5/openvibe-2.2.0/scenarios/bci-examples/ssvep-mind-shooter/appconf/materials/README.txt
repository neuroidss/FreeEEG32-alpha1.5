This folder contains materials created by the SSVEP scenarios.
