
The scenario will record its signals here.

