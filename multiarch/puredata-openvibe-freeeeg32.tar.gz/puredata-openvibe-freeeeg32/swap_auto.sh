echo '/swapfile none swap sw 0 0' | sudo tee -a /etc/fstab
