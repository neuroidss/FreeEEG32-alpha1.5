#ln -s $PWD/docker-compose-openvibe-freeeeg32.service /etc/systemd/system
systemctl restart docker-compose-puredata-openvibe-freeeeg32
