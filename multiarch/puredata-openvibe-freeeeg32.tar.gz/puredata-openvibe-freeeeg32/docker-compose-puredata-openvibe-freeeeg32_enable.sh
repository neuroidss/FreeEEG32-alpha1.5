ln -s /opt/puredata-openvibe-freeeg32/docker-compose-openvibe-freeeeg32.service /etc/systemd/system
systemctl enable docker-compose-puredata-openvibe-freeeeg32
