ln -s /opt/puredata-openvibe-freeeeg32/docker-compose-puredata-openvibe-freeeeg32.service /etc/systemd/system
systemctl enable docker-compose-puredata-openvibe-freeeeg32
