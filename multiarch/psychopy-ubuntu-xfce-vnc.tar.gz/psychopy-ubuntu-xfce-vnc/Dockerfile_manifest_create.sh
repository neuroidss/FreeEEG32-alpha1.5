docker manifest create \
neuroidss/openvibe-ubuntu-xfce-vnc:2.2.0-freeeeg32-alpha1.5 \
neuroidss/openvibe-ubuntu-xfce-vnc:2.2.0-freeeeg32-alpha1.5_amd64 \
neuroidss/openvibe-ubuntu-xfce-vnc:2.2.0-freeeeg32-alpha1.5_arm64 --amend
