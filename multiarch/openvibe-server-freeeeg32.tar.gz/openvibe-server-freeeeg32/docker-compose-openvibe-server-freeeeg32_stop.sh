#ln -s $PWD/docker-compose-openvibe-server-freeeeg32.service /etc/systemd/system
systemctl stop docker-compose-openvibe-server-freeeeg32
