#ln -s $PWD/docker-compose-openvibe-designer-freeeeg32.service /etc/systemd/system
systemctl stop docker-compose-openvibe-designer-freeeeg32
