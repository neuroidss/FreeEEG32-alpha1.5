docker image rm -f neuroidss/psychopy-ubuntu-xfce-vnc
