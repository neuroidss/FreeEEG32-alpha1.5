#docker run -it -p 5902:5901 -p 6902:6901 -p 1024:1024 -p 15361:15361 --user 0:0 --privileged -v /dev/bus/usb:/dev/bus/usb -v $PWD/psychopy:/headless/psychopy neuroidss/psychopy-ubuntu-xfce-vnc psychopy

docker run -it -p 5904:5901 -p 6904:6901 --user 0:0 --privileged -v $PWD/psychopy:/headless/psychopy neuroidss/psychopy-ubuntu-xfce-vnc
