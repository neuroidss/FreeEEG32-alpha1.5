apt-get install -y aptitude
apt-get install -y nano
apt-get install -y mc
 
apt-get install -y libsdl1.2-dev libsdl-image1.2-dev libsdl-mixer1.2-dev libsdl-ttf2.0-dev 

apt-get install -y python3-dev

apt-get install -y x11-apps

apt-get install -y python3-wxgtk-webview4.0
apt-get install -y python3-wxgtk-media4.0
