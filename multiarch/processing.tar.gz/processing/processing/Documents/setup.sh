apt-get install -y aptitude
apt-get install -y nano
apt-get install -y mc
